﻿using System;

namespace _01._2NumbersEndingIn7
{
    class Program
    {
        static void Main(string[] args)
        {
            for (int i = 7; i <= 977; i+=10)
            {
                Console.WriteLine(i);
            }
        }
    }
}
